package com.creatoraistudio.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 101, PICK_AUDIO = 102;
    private final ArrayList<Uri> images = new ArrayList<>();
    private Uri audioUri;
    private TextView imageStatus, audioStatus, notice;
    private Button prepare;

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button makeButton(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(111,94,245)));
        return b;
    }
    private void gap(LinearLayout l, int h) {
        android.view.View v = new android.view.View(this);
        l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private void refresh() {
        imageStatus.setText(images.size() + " image(s) selected");
        audioStatus.setText(audioUri == null ? "No voiceover selected" : "Voiceover selected");
        boolean ready = !images.isEmpty() && audioUri != null;
        prepare.setEnabled(ready); prepare.setAlpha(ready ? 1f : .6f);
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(17,20,38));
        getWindow().setNavigationBarColor(Color.rgb(17,20,38));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(17,20,38));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(dp(22),dp(30),dp(22),dp(24));
        scroll.addView(root);
        TextView title = label("Creator AI Studio",30,Color.rgb(173,160,255));
        title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title);
        gap(root,10);
        TextView subtitle = label("Automatic story video editor",17,Color.WHITE);
        subtitle.setGravity(Gravity.CENTER); root.addView(subtitle);
        gap(root,28);
        root.addView(label("1. Story images — select in order",17,Color.WHITE)); gap(root,8);
        Button chooseImages = makeButton("Choose story images"); root.addView(chooseImages);
        imageStatus = label("No images selected",14,Color.LTGRAY); root.addView(imageStatus);
        chooseImages.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_IMAGES);
        });
        gap(root,24);
        root.addView(label("2. Voiceover narration",17,Color.WHITE)); gap(root,8);
        Button chooseAudio = makeButton("Choose voiceover audio"); root.addView(chooseAudio);
        audioStatus = label("No voiceover selected",14,Color.LTGRAY); root.addView(audioStatus);
        chooseAudio.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i,PICK_AUDIO);
        });
        gap(root,24);
        root.addView(label("3. Video format",17,Color.WHITE));
        Spinner format = new Spinner(this);
        format.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"9:16 Shorts / Reels","16:9 YouTube"}));
        root.addView(format); gap(root,20);
        prepare = makeButton("Prepare video"); root.addView(prepare);
        notice = label("Starter build only: MP4 rendering, speech recognition, AI scene matching, subtitles and professional effects still need to be implemented.",14,Color.rgb(255,210,130));
        gap(root,14); root.addView(notice);
        prepare.setOnClickListener(v -> notice.setText("Your files are selected. The rendering engine and AI scene matching are the next development stage."));
        setContentView(scroll);
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if (res != RESULT_OK || data == null) return;
        if (req == PICK_IMAGES) {
            images.clear();
            if (data.getClipData() != null) {
                for (int i=0;i<data.getClipData().getItemCount();i++) images.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData()!=null) images.add(data.getData());
        } else if (req == PICK_AUDIO) audioUri = data.getData();
        refresh();
    }
}
